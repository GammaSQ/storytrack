
import inspect

class democlass(object):
    def demomethod(self):
        pass

class hyper_call(object):
    # describe what arguments have to be passed to a function
    def __init__(self, *needed_args):
        self.unpassed_args=[]
        self.unpassed_kwargs={}
        # if the passed_args is not a list but a callable ...
        if len(needed_args)==1 and callable(needed_args[0]):
            # ... we assume there don't have to be any specified arguments ...
            self.neded_args=[]
            # ... and invoke our own call imediately.
            return self.__call__(needed_args)
        self.needed_args=needed_args

    def __call__(self, call):
        arg_kwarg=inspect.getargspec(call)
        pre_args=arg_kwarg[0] or []
        varargs = bool(arg_kwarg[1])
        varkwargs=bool(arg_kwarg[2])
        prekwargs=list(arg_kwarg[3]) if arg_kwarg[3] else []

        missing=[]
        for n in self.needed_args:
            if n not in pre_args:
                missing.append(n)
        if missing:
            raise TypeError("%s has to get %s as arguments!"%(call.__name__, ', '.join(missing)))

        pre_kwargs={}
        prekwargs.reverse()
        for val in prekwargs:
            kw=pre_args.pop()
            pre_kwargs[kw]=val

            if type(call)==type(democlass.demomethod) or pre_args[0]=='self':
                pre_args.pop(0)
        
        def nested(*Margs, **kwargs):
            defargs=pre_args
            defkwargs=pre_kwargs.keys()
            jump=[]
            pass_args=[]
            pass_kwargs={}
            args=list(Margs)
            args.reverse()

            for defarg in defargs:
                if defarg in kwargs:
                    pass_args.append(kwargs.pop(defarg))
                else:
                    try:
                        pass_args.append(args.pop())
                    except IndexError:
                        raise TypeError("%s of %s not specified!"%(defarg, call.__name__))

            if len(pass_args)<len(defargs):
                raise TypeError("%s takes at least %i non-kw - arguments. %i defined." %(call.__name__, len(defargs), len(pass_args)))

            args.reverse()
            if len(defkwargs)<len(args):
                pass_args += args[:len(defkwargs)]
                args=args[len(defkwargs):]
                defkwargs=[]
            else:
                defkwargs=defkwargs[len(args):]
                pass_args += args
                args=[]

            for kw in defkwargs:
                if kw in kwargs:
                    pass_kwargs[kw]=kwargs.pop(kw)

            self.unpassed_args=args
            self.unpassed_kwargs=kwargs

            pass_args += args if varargs else []
            if varkwargs:
                pass_kwargs = dict(pass_kwargs.items() + kwargs.items())
            return call(*pass_args, **pass_kwargs)
        return nested

    def last_unpassed(self, kwargs=False):
        if kwargs:
            return self.unpassed_kwargs

        return self.unpassed_args

    def last_unpassed_args(self):
        return self.unpassed_args

    def last_unpassed_kwargs(self):
        return self.unpassed_kwargs

def react(func):
    func.act=False
    return func

def act(func):
    func.act=True
    return func

class Handler(object):
    handlers={}
    def __new__(cls, handler, event=None):
        if event:
            if event.name in cls.handlers:
                cls.handlers[event.name].append(handler)
            else:
                cls.handlers[event.name]=[handler]
        return cls.__init__(handler)

    def __init__(self, handler):
        self.handler = handler

    def __set__(self, event):
        handlers[event.name].append(self.handler)
        event.handlers.append(self)

    def handle(self, event):
        if event == self.event:
            return self.handler(event)

class Event(object):
    def __init__(self, event):
        self.handlers=[]
        if callable(event):
            name=event.__name__
        else:
            name=event
            def ev(**kwargs):
                return event
            event=ev

        self.event=event
        self.name=name

    def __call__(self, func=None, **kwargs):
        if callable(func):
            self.event=func
        else:
            for hand in self.handlers:
                if hand(self)=="catch":
                    break
            return True